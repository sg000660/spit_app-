import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-placements',
  templateUrl: './placements.page.html',
  styleUrls: ['./placements.page.scss'],
})
export class PlacementsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
