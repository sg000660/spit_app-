import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admission',
  templateUrl: './admission.page.html',
  styleUrls: ['./admission.page.scss'],
})
export class AdmissionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
